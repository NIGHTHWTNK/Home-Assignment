import Foundation

struct cartItem: Codable {
	let name: String
	let category: String
	let price: Int
	let amount: Int
}

enum DiscountType {
	case fixedAmount(Double)
	case percentage(Double)
	case categoryPercentage(String, Double)
	case points(Int)
	case seasonal(Double, Double)
}


func decodeJSON(_ cartJSON: String) -> [cartItem] {
	guard let sources = Bundle.main.url(forResource: cartJSON, withExtension: "json") else {
		fatalError("Could not find \(cartJSON).json")
	}

	guard let cartData = try? Data(contentsOf: sources) else {
		fatalError("Could not conver data")
	}

	guard let cartItems = try? JSONDecoder().decode([cartItem].self, from: cartData) else {
		fatalError("Failed to decode JSON")
	}
	
	return cartItems
}

let cartItem1 = decodeJSON("cartItem1")

func calculate(cart: [cartItem], discountType: DiscountType) -> Int {
//	cartItems.reduce(0) { $0 + ($1.price * Double($1.quantity)) }
	let price = cart.reduce(0) { $0 + ($1.price * $1.amount) }
	
	return price
}

calculate(cart: cartItem1, discountType: .fixedAmount(50))
